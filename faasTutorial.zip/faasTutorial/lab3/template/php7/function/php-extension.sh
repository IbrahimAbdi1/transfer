#!/bin/sh

echo "Installing PHP extensions"

# Add your extensions in here, an example is below
# docker-php-ext-install mysqli
#
# See the template documentation for instructions on installing extensions;
# - https://github.com/openfaas/templates/tree/master/template/php7
#
# You can also install any apk packages here
