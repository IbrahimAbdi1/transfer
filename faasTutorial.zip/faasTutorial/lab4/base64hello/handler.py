import os
import requests
import sys

def handle(req):
    """
    gateway_hostname = os.getenv("gateway_hostname", "gateway") # uses a default of "gateway" for when "gateway_hostname" is not set

    test_sentence = req
    """
    arg = req

    r = requests.get("http://gateway:8080/function/base64", data=arg)
    if r.status_code != 200:
        sys.exit("Error with base64, expected: %d, got: %d\n" % (200, r.status_code))

    r = requests.get("http://gateway:8080/function/hello-openfaas", data=r.text)
    if r.status_code != 200:
        sys.exit("Error with hello-openfaas, expected: %d, got: %d\n" % (200, r.status_code))


    # http://docs.python-requests.org/en/master/
    return r.text
